import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:practice/screen/Home/service/gemini_service.dart';
import 'package:practice/screen/Home/widget/post_card.dart';
import 'package:practice/screen/Home/widget/left_tab.dart'; // 動作：ドロワーメニューの LeftTab を読み込む！

class MainSled extends StatefulWidget {
  const MainSled({super.key});

  @override
  State<MainSled> createState() => MainSledState();
}

class MainSledState extends State<MainSled> {
  // 動作：画面に表示する投稿データのリスト
  final List<Map<String, dynamic>> posts = [];

  // 動作：切り出したGeminiサービスの実体を作成
  final GeminiService _geminiService = GeminiService();

  // 動作：いいねされた投稿だけをその場で抽出してリストにして返すヘルパー関数
  List<Map<String, dynamic>> get _favoritePosts {
    return posts.where((post) => post['isFavorite'] == true).toList();
  }

  // 動作：特定の投稿の「いいね」状態をパチパチ切り替える関数
  void toggleFavorite(Map<String, dynamic> targetPost) {
    setState(() {
      // 動作：タップされた特定の投稿データ内の「isFavorite」の値を、現在の真逆（反転）にする
      targetPost['isFavorite'] = !(targetPost['isFavorite'] ?? false);
    });
  }

  // 動作：特定の投稿の「共有」状態とカウント数を切り替える関数（追加）
  void toggleShare(Map<String, dynamic> targetPost) {
    setState(() {
      // 動作：もしデータ内にまだカウントがなければ初期値0をセット
      if (targetPost['shareCount'] == null) {
        targetPost['shareCount'] = 0;
      }

      if (targetPost['isShared'] == true) {
        // 動作：すでに共有済み（緑）なら、解除してカウントを1減らす
        targetPost['isShared'] = false;
        targetPost['shareCount']--;
      } else {
        // 動作：まだ共有していないなら、共有状態にしてカウントを1増やす
        targetPost['isShared'] = true;
        targetPost['shareCount']++;
      }
    });
  }

  // 動作：特定の投稿のコメント用のダミー関数（追加）
  void toggleCommentDummy(Map<String, dynamic> targetPost) {
    setState(() {
      targetPost['isChatBubbleOutline'] =
          !(targetPost['isChatBubbleOutline'] ?? false);
    });
  }

  // 動作：新しくAIの投稿を生成して、Firebaseに保存する関数
  Future<void> fetchNewPost() async {
    // 動作：裏側のGeminiサービスから新しく生成されたAIデータを取得
    final data = await _geminiService.generateAiPost();

    if (data != null) {
      try {
        // 動作：Firestoreの「posts」というコレクション（フォルダ）にデータを新規保存する！
        await FirebaseFirestore.instance.collection('posts').add({
          "user": data['name'], // 動作：AIが考えたユーザー名
          "icon": data['icon_url'], // 動作：アイコンの画像URL
          "content": data['post'], // 動作：つぶやき本文
          "role": data['role'], // 動作：キャラクターの性格設定
          "isFavorite": false, // 動作：いいねの初期状態（お気に入り登録は最初 false）
          "isShared": false, // 動作：共有初期状態
          "shareCount": 0, // 動作：共有数初期値
          "createdAt": FieldValue.serverTimestamp(),
        });

        print("Firebaseへのデータ保存に成功したぜ！");
      } catch (e) {
        print("Firebase保存エラー: $e");
      }

      // 動作：これまでのアプリ内リストに即時反映させるsetState
      setState(() {
        posts.insert(0, {
          "user": data['name'],
          "icon": data['icon_url'],
          "content": data['post'],
          "role": data['role'],
          "isFavorite": false,
          "isShared": false,
          "shareCount": 0,
        });
      });
    }
  }

  @override
  void initState() {
    super.initState();
    // 動作：アプリ起動時に自動で1個目の投稿を読み込む
    fetchNewPost();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // 動作：ドロワーを置けるようにScaffoldで囲むよ
      // 動作：ドロワー（サイドメニュー）として LeftTab を呼び出す
      // 💡 MyProfileにバケツリレーするため、関数を多めに引き渡すよ！
      drawer: LeftTab(
        likedPosts: _favoritePosts,
        onFavoriteToggle: toggleFavorite,
        onShareToggle: toggleShare, // 動作：追加
        onChatBubbleOutline: toggleCommentDummy, // 動作：追加
      ),

      body: Column(
        children: [
          // 動作：AIに呟かせるための最上部の青いボタン
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: ElevatedButton.icon(
              onPressed: fetchNewPost,
              icon: const Icon(Icons.auto_awesome),
              label: const Text('AIに呟かせる'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                foregroundColor: Colors.white,
              ),
            ),
          ),

          // 動作：タイムラインのリスト表示エリア
          Expanded(
            child: RefreshIndicator(
              color: Colors.blueAccent,
              backgroundColor: Colors.grey,
              onRefresh: () async {
                await fetchNewPost();
              },
              child: ListView.separated(
                physics: const AlwaysScrollableScrollPhysics(),
                itemCount: posts.length,
                itemBuilder: (context, index) {
                  final post = posts[index];

                  // 動作：共通の PostCard を呼び出す（バトンパスを最新化）
                  return PostCard(
                    post: post,
                    onFavoriteTap: () => toggleFavorite(post),
                    onShareTap: () => toggleShare(post), // 動作：共有処理を紐付け
                    onCommentTap: () {
                      // 動作：コメントはのちに画面遷移するので今はログを出す
                      print('${post['user']} さんの投稿へのコメント画面へ遷移するよ！');
                    },
                    onUserTap: () {
                      print('${post['user']} さんのプロフ画面へ遷移するよ！');
                    },
                  );
                },
                separatorBuilder: (context, index) =>
                    const Divider(color: Colors.white10),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

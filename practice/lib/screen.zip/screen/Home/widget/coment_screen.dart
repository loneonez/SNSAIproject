import 'package:flutter/material.dart';

// 動作：コメント入力と一覧を表示する新しい画面Widget
class CommentScreen extends StatefulWidget {
  const CommentScreen({super.key});

  @override
  State<CommentScreen> createState() => _CommentScreenState();
}

class _CommentScreenState extends State<CommentScreen> {
  // 動作：入力されたコメントの文字を管理するコントローラー
  final TextEditingController _commentController = TextEditingController();

  // 動作：画面に表示するコメントデータの仮リスト（本当はFirebaseと繋ぐけど、まずはアプリ内だけで動かすよ！）
  final List<String> _comments = ["この投稿めっちゃ面白いですね！", "なるほど、勉強になります！"];

  // 動作：新しいコメントを追加する関数
  void _addComment() {
    if (_commentController.text.trim().isNotEmpty) {
      setState(() {
        // 動作：リストの最後に、入力された文字を追加する
        _comments.add(_commentController.text);
      });
      // 動作：送信が終わったら、入力欄の文字をきれいに消す
      _commentController.clear();
    }
  }

  @override
  void dispose() {
    // 動作：画面が閉じられたら、メモリ解放のためにコントローラーを破棄する
    _commentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // 動作：アプリのテーマに合わせて黒背景
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text(
          'コメント',
          style: TextStyle(color: Colors.white, fontSize: 18),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context), // 動作：タイムライン画面に戻る
        ),
      ),
      body: Column(
        children: [
          // 💡 1. 元の投稿を表示するエリア（まずはダミーの見た目で作ってあるよ）
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            color: Colors.white10,
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'AIユーザー',
                  style: TextStyle(
                    color: Colors.grey,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'ここにタップされた元の投稿本文が表示されるように、のちのち改造していこうな！',
                  style: TextStyle(color: Colors.white),
                ),
              ],
            ),
          ),
          const Divider(color: Colors.white24, height: 1),

          // 💡 2. コメント一覧表示エリア
          Expanded(
            child: _comments.isEmpty
                ? const Center(
                    child: Text(
                      'まだコメントがありません',
                      style: TextStyle(color: Colors.grey),
                    ),
                  )
                : ListView.builder(
                    itemCount: _comments.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: Colors.blueAccent,
                          child: Icon(
                            Icons.person,
                            color: Colors.white,
                            size: 16,
                          ),
                        ),
                        title: Text(
                          _comments[index],
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                          ),
                        ),
                      );
                    },
                  ),
          ),

          // 💡 3. 一番下のコメント入力エリア
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _commentController,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: 'コメントを追加...',
                        hintStyle: const TextStyle(color: Colors.grey),
                        filled: true,
                        fillColor: Colors.white10,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 10,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  // 動作：紙飛行機の形をした送信ボタン
                  IconButton(
                    icon: const Icon(Icons.send, color: Colors.blueAccent),
                    onPressed: _addComment, // 動作：タップされたら上の追加関数を実行！
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

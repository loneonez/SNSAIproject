import 'package:flutter/material.dart';
import 'package:practice/screen/Home/widget/left_tab.dart';
import 'package:practice/screen/Home/widget/main_sled.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // 動作：MainSledState（タイムライン画面の状態）を外から操作・参照するためのキー
  final GlobalKey<MainSledState> _mainSledKey = GlobalKey<MainSledState>();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.black,

      drawer: LeftTab(
        // まだMainSledが作られていない最初の瞬間（nullのとき）は、空のリスト「[]」を渡すようにしているよ！
        likedPosts: _mainSledKey.currentState != null
            ? _mainSledKey.currentState!.posts
                  .where((post) => post['isFavorite'] == true)
                  .toList()
            : [],

        // 動作：お気に入りボタンが押されたとき、_mainSledKeyを通してMainSledの「toggleFavorite」関数を実行するよ！
        onFavoriteToggle: (post) {
          _mainSledKey.currentState?.toggleFavorite(post);
          setState(() {});
        },

        // 動作：共有ボタンが押されたとき、_mainSledKeyを通してMainSledの「toggleShare」関数を実行する（追加）
        onShareToggle: (post) {
          _mainSledKey.currentState?.toggleShare(post);
          setState(() {});
        },

        // 動作：コメント用のダミー関数を実行する（追加）
        onChatBubbleOutline: (post) {
          _mainSledKey.currentState?.toggleCommentDummy(post);
          setState(() {});
        },
      ),

      appBar: AppBar(
        backgroundColor: Colors.transparent, // 動作：背景を透明に
        elevation: 0, // 動作：影を消す
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: GestureDetector(
            onTap: () {
              // 動作：アイコンをタップした時に、HomeScreen全体を一度再描画してからメニュー（Drawer）を開く
              // これをすることで、最新のいいね状態がメニュー（LeftTab）にしっかり反映されるんだぜ！
              setState(() {
                _scaffoldKey.currentState?.openDrawer();
              });
            },
            child: const CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(Icons.person, color: Colors.black, size: 20),
            ),
          ),
        ),
      ),

      // 3. メインコンテンツ（タイムライン表示エリア）
      body: Stack(
        children: [
          // 動作：タイムライン本体。ここにキーをセットすることで、上のDrawerからアクセスできるようになるよ！
          SafeArea(child: MainSled(key: _mainSledKey)),

          // 動作：前に作ったガラスのボトムバーを一番下に浮かせる（もし使うならコメントアウトを外してね）
          const Align(
            alignment: Alignment.bottomCenter,
            // child: ScreenBottomBar(),
          ),
        ],
      ),
    );
  }
}
